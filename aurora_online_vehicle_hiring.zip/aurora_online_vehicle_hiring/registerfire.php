<?php
    $a = $_POST["fname"];
	$b = $_POST["lname"];
	$c = $_POST["email"];
    $d = $_POST["contact"];
    $e = $_POST["username"];
    $f = $_POST["pass"];
    $g = $_POST["cpass"];
    $h = $_POST["seq"];
    $i = $_POST["ans"];
    //echo "'$a','$b','$c','$d','$e','$f','$h','$i'";
    include("conn.php");
    $qry="insert into register values('$a','$b','$c','$d','$e','$f','$h','$i')";    
    $res=mysql_query($qry);
    echo $res;
     if($res==1)
     {
         echo "<script> alert('Register successfully')</script>";
         echo "<script> window.location.href='signin.php' </script>";
       }
        else{
            echo"<script> alert('error 404')</script>";
        }
?>