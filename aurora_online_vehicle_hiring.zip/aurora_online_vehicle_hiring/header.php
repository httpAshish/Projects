<?php
	include('conn.php');
	session_start();
	$user=$_SESSION['user'];    
	if($user=="")
	{
		$user="Guest";
        
    }
	else
	{
		$qry="select * from register where username='$user'";
		$rr=mysql_query($qry);
		$row=mysql_fetch_array($rr);
		$user=$row[0];
	}
	
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Aurora||Online||Vehicle||Booking</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700;900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/ashish.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Offcanvas Menu Begin -->
    <div class="offcanvas-menu-overlay"></div>
    <div class="offcanvas-menu-wrapper">
        <div class="offcanvas__logo">
            <a href="./index.html"><img src="img/logo.png" alt=""></a>
        </div>
        <div id="mobile-menu-wrap"></div>
        <ul class="offcanvas__widget__add">
            <li><i class="fa fa-clock-o"></i> Week day: 08:00 am to 18:00 pm</li>
            <li><i class="fa fa-envelope-o"></i> Info.colorlib@gmail.com</li>
        </ul>
        <div class="offcanvas__phone__num">
            <i class="fa fa-phone"></i>
            <span>(+12) 345 678 910</span>
        </div>
        <div class="offcanvas__social">
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-google"></i></a>
            <a href="#"><i class="fa fa-instagram"></i></a>
        </div>
    </div>
    <!-- Offcanvas Menu End -->

    <!-- Header Section Begin -->
    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <ul class="header__top__widget">
                        <li><p class="link2"><strong><b>Welcome <span class="miwt"> <?php echo $user ?></span></b></strong></p>  </li>
                        <li><i class="fa fa-clock-o"></i> Week day: 08:00 am to 18:00 pm</li> 
                    </ul>
                    </div>
                    <div class="col-lg-6">
                        <div class="header__top__right">
                            <ul class="header__top__widget">
                             <li class="miwt"><i class="fa fa-user" ></i><a href="profile.php" class="miwt"> Edit Profile <a href="signout.php" class="link2">||Signout</a> </li> 
                              </div>                  
                            </div>
                    </div>      
                </div>
         </div>
            </div>      

        <div class="container">
            <div class="row">
                <div class="col-lg-2">
                    <div class="header__logo">
                        <a href="./index.html"><img src="img/logo.png" alt=""></a>
                    </div>
                </div>
                <div class="col-lg-10">
                    <div class="header__nav">
                        <nav class="header__menu">
                            <ul>
                                <li><a href="./index.php">Home</a></li>
                                <li><a href="vehicle.php">Vehicles</a></li>
                                <li><a href="book.php">Booking</a></li>
                                <li><a href="estimate.php">Estimate </a></li>
                                <li><a href="routes.php">Routes </a></li>
                                <li><a href="feedback.php">feedback </a></li>
                                <a href="Signin.php" class="primary-btn">Signin</a>

                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
            <div class="canvas__open">
                <span class="fa fa-bars"></span>
            </div>
        </div>
        
    </header>
