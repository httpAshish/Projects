<?php

	$a = $_POST["username"];
	$b = $_POST["pass"];
	
	
	include("conn.php");
	$sel = "select * from register where username='$a' and password='$b' ";
	$res = mysql_query($sel);
	$count = mysql_num_rows($res);
	
	if($count==1)
	{
		session_start();
		$_SESSION['user']=$a;	
		echo "<script> alert('Login Successfully'); </script>";
		echo "<script> window.location = 'index.php' </script>";
	}
	else
	{
		echo "<script> alert('Login credential are incorrect'); </script>";
		echo "<script> window.location = 'signin.php' </script>";
	}
	
	
	
?>