<?php include('header.php')?>
<div class="breadcrumb-option set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>Retrieve your password</h2>
                        <div class="breadcrumb__links">
                            <a href="./index.php"><i class="fa fa-home"></i> Home</a>
                            <span>retrieve password</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- Contact Section Begin -->
    <section class="contact spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="contact__text">
                        <div class="section-title">
                        </div>
                    </div>
                </div>

                <div class="col-lg-7">
                    <div class="contact__form">
                        <form action="#">
                            <div class="row">
                                <div class="col-lg-12">
                                    <label>username- </label>
                                    <input type="username" required>
                                </div>
                                <div class="col-lg-12">
                                    <label>Email- </label>
                                    <input type="email" required>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-12">
                                        <label class="col-md-12"> security questions?</label>
                                        <div class="col-md-12">
                                            <select name="seq" class="form-control col-lg-12" required
                                                style="width: 750px;  font-size:50px; height: 58px; ">
                                                <option> Select security Question from the list.. </option>
                                                <option> What is your favourite colour? </option>
                                                <option> What is your favourite fruite? </option>
                                                <option> what is your childhood name? </option>
                                                <option> which is your favourite sports? </option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label>Answer </label>
                                    <input type="text" required>
                                </div>
                                <div class="text-center col-lg-10">
                                    <button type="submit" class="site-btn col-lg-5">Retrieve Password </button>
                                </div>
                                <br>
                                <div class="col-lg-12">
                                </div>
                                <div class="col-lg-12">
                                </div>
                                <div class="text-center col-10">
                                    <a href="registartion.php" class="ashish">New user </a>
                                    <span>||</span>
                                    <a href="sigin.php" class="ashish">signin </a>
                                </div>
                            </div>
                      </div>
                </div>
                </form>
            </div>
        </div>

        </div>
        </div>
    </section>
    <!-- Contact Section End -->
</body>
</html>
<?php include('footer.php')?>