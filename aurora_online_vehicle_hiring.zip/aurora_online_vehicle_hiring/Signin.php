<?php include('header.php')?>
    <!-- Header Section End -->

    <!-- Breadcrumb End -->
    <div class="breadcrumb-option set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>Sign-in to your account</h2>
                        <div class="breadcrumb__links">
                            <a href="./index.php"><i class="fa fa-home"></i> Home</a>
                            <span>Sign-in</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Begin -->

    <!-- Contact Section Begin -->
    <section class="contact spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="contact__text">
                        <div class="section-title">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="contact__form">
                        <form action="signinfire.php" method="post">
                            <div class="row">
                                <div class="col-lg-10">
                                    <label>Username:- </label>
                                    <input type="username" name="username" required>
                                </div>
                                <div class="col-lg-10">
                                    <label>Password:- </label>
                                    <input type="password" name="pass" required>
                                </div>
                            </div>
                            <div class="text-center col-lg-10">
                                <button type="submit" class="site-btn col-lg-5">SignIn </button>
                            </div>
                            <br>
                            <div class=" text-center col-lg-10">
                                <a href="registartion.php" class="ashish" >New user  </a>
                               <span> || </span>
                                <a href="forgotpassword.php"   class="ashish">Forgot password </a>
                            </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
        </div>
    </section>
    <!-- Contact Section End -->

    <!-- Contact Address End -->

  </body>
</html>
<?php include('footer.php')?>