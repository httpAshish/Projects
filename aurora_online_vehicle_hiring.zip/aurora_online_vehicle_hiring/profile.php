<?php include('header.php')?>
<?php
		session_start();
		$id=$_SESSION['user'];
		//echo $id;
		if($id=="")
		{
			echo"<script> alert('Please signin or Register your account..!'); </script>";
			echo "<script> window.location.href='signin.php'; </script>";
		}
?>
<?php 	
	$qry="select * from register where username='$id'";
	$rcc=mysql_query($qry);
	$r=mysql_fetch_array($rcc);
?>
    <div class="breadcrumb-option set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>Edit Profile</h2>
                        <div class="breadcrumb__links">
                            <a href="./index.html"><i class="fa fa-home"></i> Home</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="about spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title about-title">
                    <div class="car__item__text">
                         <div class="col-lg-12">
                         <h3 class="mycl"><?php echo $row[1]?></h3>
        </div> 
</div>  

<?php include('footer.php')?>
