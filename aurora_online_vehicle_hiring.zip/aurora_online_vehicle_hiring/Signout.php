<?php 
	
	session_start();
	if(isset($_SESSION['user']))
	{
  		unset($_SESSION['user']);
		  unset($_SESSION['vehicle']);
		  unset($_SESSION['route']);
		  unset($_SESSION['rrr']);
		  unset($_SESSION['rrr']);
		  unset($_SESSION['ppp']);
  
	}

  	header("location:index.php");
?>
			