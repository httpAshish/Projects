    
    function validateForm(){        
        var name=document.forms['myform']['fname'].value;
        console.log(name);
        return false;
                           }