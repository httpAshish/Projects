<?php include('header.php')?>
    <!-- Breadcrumb End -->
    <div class="breadcrumb-option set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>Give us feedback</h2>
                        <div class="breadcrumb__links">
                            <a href="./index.php"><i class="fa fa-home"></i> Home</a>
                            <span>Feedback </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Begin -->

    <!-- Contact Section Begin -->
    <section class="contact spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="contact__text">
                        <div class="section-title">
                        </div>
                    </div>
                </div>
    
              <div class="col-lg-6 col-md-6">
                    <div class="contact__form">
                        <form action="feedbackfire.php" method="post">
                            <div class="row">
                                <div class="col-lg-12">
                                    <label>Username:- </label>
                                    <input type="username" name="user"  required>
                                </div>
                                <div class="col-lg-12">
                                    <label>Email:- </label>
                                    <input type="email"  name="email" required>
                                    <label>your comments:- </label>
                                    <textarea name="comm"></textarea>
                                </div>
                            </div>
                            <div class="text-center col-lg-10">
                                <button type="submit" class="site-btn col-lg-5">Submit  </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact Section End -->

    <!-- Contact Address End -->
  </body>

</html>
<?php
 include('footer.php')
?>