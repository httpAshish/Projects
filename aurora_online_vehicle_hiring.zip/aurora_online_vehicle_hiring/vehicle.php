<?php include('header.php') ?>
<?php
	$qry="select * from vehicle_master order by flag desc";
	$rc=mysql_query($qry);
?>

<div class="breadcrumb-option set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>Vehicle Listing</h2>
                        <div class="breadcrumb__links">
                        <a href="index.php"><i class="fa fa-home"></i>Back to home page</a>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="car spad ">

    <?php $i=0; // counter ?>

<?php while ($row=mysql_fetch_array($rc)) {?> 

    <?php if ($i%4==0) { // if counter is multiple of 3 ?>
    <div class="row">
    <?php } ?>

    <div class="col-md-3 img-portfolio">
    <?php echo"<a href='vehicledes.php?code=$row[0]'>  <img class='img-responsive img-hover' src='admin/vehicle_img/$row[11]'>  </a>"; ?>
    <div class="car__item__text">
    <h4 class="mycl"><?php echo $row[1] ?></h4>      
    <h6><?php echo "<a href='vehicledes.php?code=$row[0]' class='mm'> <i class='fa fa-external-link' aria-hidden='true'></i> View vehicle details</a>";?> </h6></div>  
    </div>        

    <?php $i++; ?>

    <?php if($i%4==0) { // if counter is multiple of 3 ?>
    </div>
    <?php } ?>

	<?php } ?>
</div>
    </section>
    <?php include('footer.php') ?>