<?php include('header.php') ?>
<?php
@session_start();
$uname = $_SESSION['user'];
$qry = "select * from register where username='$uname'";
$rcc = mysql_query($qry);
$r = mysql_fetch_array($rcc);
$q1 = "select * from distance";
$rd = mysql_query($q1);
$q2 = "select * from vehicle_master";
$r2 = mysql_query($q2);
?>
<!-- Header Section End -->
<!-- Breadcrumb End -->
<div class="breadcrumb-option set-bg" data-setbg="img/call-bg.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <div class="breadcrumb__links">
                        <a href="index.php"><i class="fa fa-home"></i>Back to home page</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="col-lg-3">
        <div class="contact__text">
            <div class="section-title">
            </div>
        </div>
    </div>
</div>
<div class="section-title team-title">
    <h2>Get your estimate </h2>
    <br>
    <section class="contact spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="contact__text">
                        <div class="section-title">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-lg-3">
                <form class="form-horizontal" method="post" action="estimatefire.php"> 
                    <label class="lab3">Select routes from below:</label>
                    <select name="lstroute" class="drop" required >
                        <?php
                            while ($rdd = mysql_fetch_array($rd)) {
                            
                                echo "<option> $rdd[0] </option>";
                        }
                        ?>
                    </select>
                </div>
                <br>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="contact__text">
                                <div class="section-title">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-lg-3">
                            <label class="lab3">Select vehicle from below:</label>
                        <select class="drop" name="lstvehicle"> 
                        <?php    
                                    while ($re = mysql_fetch_array($r2)) {
                                        echo "<option> $re[1] </option>";
                                }
                                ?> 
                            </select>
                        </div>
                        <div class="container">
                            <div class="col-lg-3">
                                <div class="contact__text">
                                    <div class="section-title">
                                    </div>
                                </div>
                            </div>
                            </div>
                            <div class="row col-md-12">
                                <div class="form-group col-md-12">
                                    <input type="submit" class="site-btn col-2" value="Get estimate..!">
                                </div>
                            </div>
                         </div>
                     </div>
    </section>      
      <?php include('footer.php') ?>
    </body>
    </html>