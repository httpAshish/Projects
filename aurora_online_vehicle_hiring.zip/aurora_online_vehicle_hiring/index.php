<?php include('header.php') ?>
<?php include('midpart.php') ?>
<?php include('footer.php') ?>