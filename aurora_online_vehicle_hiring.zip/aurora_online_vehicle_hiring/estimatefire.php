
<?php include("header.php"); ?>
<?php
	  		$t1=$_POST['lstroute'];
			$t2=$_POST['lstvehicle'];
?>
<?php 
	$q1="select * from distance where station='$t1'";
	$rd=mysql_query($q1);
	$q2="select * from vehicle_master where name='$t2'";
	$r2=mysql_query($q2);
	$km=mysql_fetch_array($rd);
	$pr=mysql_fetch_array($r2);
?>
<div class="breadcrumb-option set-bg" data-setbg="img/call-bg.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <div class="breadcrumb__links">
                    <a href="index.php"><i class="fa fa-home"></i>Back to home page</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="col-lg-3">
        <div class="contact__text">
            <div class="section-title">
            </div>
        </div>
    </div>
</div>
<div class="section-title team-title">
    <h2>Get your estimate </h2>
    <br>
    <section class="contact spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="contact__text">
                        <div class="section-title">
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-lg-3">
				<label class="estilab">Selected Route:</label>
		  	<h3 class="size"><?php echo $t1 ?></h3>
		
 </div>
                <br>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="contact__text">
                                <div class="section-title">
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-lg-6 col-lg-3">
						<label class="estilab">Selected Vehicle:</label>
	  					<h3 class="size"><?php echo $t2 ?></h3>
</div>
	          <div class="container">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="contact__text">
                                <div class="section-title">
                                </div>
                            </div>
                        </div>
                        
						 <div class="col-lg-6 col-lg-3">
						 <label class="estilab">Total Kilometers:</label>
	 				 <h3 class="size"><?php echo $km[1] ?></h3>
	   						</div>
				<div class="container">
                    <div class="row">
                        <div class="col-lg-3">  
                            <div class="contact__text">
                                <div class="section-title">
                                </div>
                            </div>
                        </div>
						 <div class="col-lg-6 col-lg-3">
						 <label class="estilab">Approx timing:-</label>
	 				 <h3 class="size"><?php echo $km[2] ?></h3>
	   						</div>
							   <div class="container">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="contact__text">
                                <div class="section-title">
                                </div>
                            </div>
                        </div>
						 <div class="col-lg-6 col-lg-3">
						 <label class="estilab">prize per kilometer:-</label>
	 				 <h3 class="size"><?php echo $pr[9] ?></h3>
	   						</div>
				<div class="container">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="contact__text">
                                <div class="section-title">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-lg-3">
						<label class="estilab"> total:- </label>
					 <h3 class="si">Total estimate:-
					 <?php 
	  	$price=$pr[9];
		$km=$km[1];
		$tot=$price * $km;
		echo $tot;
	  ?>
					</h3>
	   						</div>
                               <div class="container">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="contact__text">
                                <div class="section-title">
                                </div>
                            </div>
                        </div>
                        <div class="container">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="contact__text">
                                <div class="section-title">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                        <a class=" site-btn col-lg-5 "  href="book.php?tot=<?php echo $tot ?>&vehicle=<?php echo $t2 ?>&route=<?php echo $t1 ?>" role="button">Book..!</a>       </div>
    </section>      
    </body>
    </html>
    <?php include('footer.php') ?>