<?php include('header.php')?>
<?php
		session_start();
		$id=$_SESSION['user'];
		//echo $id;
		if($id=="")
		{
			echo"<script> alert('Please signin or Register your account..!'); </script>";
			echo "<script> window.location.href='signin.php'; </script>";
		}
?>
<?php 
	$qry="select * from register where username='$id'";
	$rcc=mysql_query($qry);
	$r=mysql_fetch_array($rcc);
?>
<?php  
$code=$_GET['code'];
$qry="select * from vehicle_master where code='$code'";
$rc=mysql_query($qry);
$row=mysql_fetch_array($rc);
//$desc=$_GET['desc'];
?>
    <div class="breadcrumb-option set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>Book Your Trip</h2>
                        <div class="breadcrumb__links">
                            <a href="./index.html"><i class="fa fa-home"></i> Home</a>
                            <span>Booking </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="contact spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-6">
                    <div class="contact__text  col-lg-6 ">
                        <h3 class="estm">  Calculate Estimate  </h2>       
          <ul>
                            <?php
						$rr=$_GET['route'];
						$vv=$_GET['vehicle'];
						$tt=$_GET['tot'];
						$y="select * from vehicle_master where name='$vv'";
						$ry=mysql_query($y);
						$rar=mysql_fetch_array($ry);
						$i=$rar[11];
						if($rr==""){
                        echo "<li> <a href='estimate.php' class='link1 '>Select estimate</a></li>";
                        }
                        else
						{
							echo " <p class='aj'>Route : $rr </p>";
							$_SESSION['rrr']=$rr;
						
                        }
						if($vv=="")
							echo "<li><a href='vehicle.php' class='link1'>Select vehicle</li></a>";
						else
						{
                            
                            echo "<p class='aj'>Vehicle Name : $vv </p></div>"; 
							$_SESSION['vvv']=$vv;
					    	echo "<p><img class='car__item__text img-responsive col-lg-5' src='img/car/$i' ></p>";
                            echo "<p class='ak'>Price : Rs. $tt </p>";
							$_SESSION['ppp']=$tt; 
						
                        }	
					?>          
                        </ul>
                    </div>
                </div>
                <div class="col-lg-12 col-md-6">
                    <div class="contact__form">
                    <form action="bookingfire.php" method="post" name="myform" >
                        <div class="row">
                                <div class="col-lg-6">
                                    <label>Name:- </label>
                                    <input type="name" name="name" value="<?php echo $r[4]?>" required>
                                    </div>
                                <div class="col-lg-6">
                                    <label>Email- </label>
                                    <input type="email" name="email"  required value="<?php echo $r[2]?>">
                                </div>
                                <div class="col-lg-6">
                                    <label>Contact number </label>
                                    <input type="tel" name="contact"  required value="<?php echo $r[3]?>">
                                </div>
                                 <div class="col-lg-6">
                                    <label>City name </label>
                                    <input type="text"  name="city" required>
                                </div>
                                <div class="col-lg-6">
                                    <label>Adult passenger </label>
                                    <input type="number" name="apr" required>
                                </div>
                                <div class="col-lg-6">
                                    <label>Child passenger </label>
                                    <input type="number" name="cpr" required>
                                </div>
                                <div class="col-lg-6">
                                    <label>Pick-Up Address </label>
                                    <input type="text" name="padd" required>
                                </div>
                                <div class="col-lg-6">
                                    <label>Pick-Up Date </label>
                                    <input type="date" name="date" required>
                                </div>
                                <div class="col-lg-6">
                                    <label>Pick-Up Time </label>
                                    <input type="time" name="time" required>
                                </div>
                                <div class="col-lg-12">
                                <label>Describe route </label>
                                <textarea name="rt" required> </textarea><br> 
                                <div class="col-lg-12">
                                <button type="submit" class=" site-btn col-lg-12">Book My Trip..! </button>            
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div> 
    </div>
</div>    
</section>

            </section>
<?php include('footer.php')?>
