<?php
	include("conn.php");
	session_start();
	$id=$_SESSION['user'];
	date_default_timezone_set('Asia/Calcutta');
	$dnt = date('dmYhis', time());

	$a= $id.$dnt;
	$b= $_SESSION['vvv'];
	$c= $_SESSION['rrr'];
	$d=$_POST['name'];
	$e=$_POST['email'];
	$f=$_POST['contact'];
	$g=$_POST['city'];
	$h=$_POST['apr'];
	$i=$_POST['cpr'];
	$j=$_POST['padd'];
	$k=$_POST['date'];
	$l=$_POST['time'];
	$m=$_POST['rt'];
	$n= $_SESSION['ppp'];
	
	mysql_query("insert into booking values('$a', '$b', '$c', '$d', '$e', '$f', '$g', '$h', '$i', '$j', '$k', '$l', '$m', '$n')");
	echo "<script>window.location='index.php'; </script>";
?>