<?php
	$id=$_GET['id'];
	//echo $id;
	include('conn.php');
	$q4=mysql_query("delete from booking where code='$id'");
	//echo "delete from subject where code='$id'";
	echo "<script> window.location='booking.php'; </script>";
?>	