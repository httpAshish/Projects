<?php
	$id=$_GET['id'];
	//echo $id;
	include('conn.php');
	$q4=mysql_query("delete from vehicle_master where code='$id'");
	//echo "delete from subject where code='$id'";
	echo "<script> window.location='travelmasterdel.php'; </script>";
	echo "<script> alert('delete data success') </script>";
?>	