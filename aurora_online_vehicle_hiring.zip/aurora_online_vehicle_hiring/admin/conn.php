<?php
    $server = "localhost";
    $username = "root";
    $password = "";
    $dbname = "aurora";
    $conn = mysql_connect($server,$username,$password);
    $db = mysql_select_db($dbname);
?>