<?php
		session_start();
		$id=$_SESSION['admin'];
		//echo $id;
		if($id=="")
		{
			echo"<script> alert('Please login first...'); </script>";
			echo "<script> window.location.href='index.php'; </script>";
		}
?>
<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Aurora||Online||Vehicle||Booking</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700;900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="../css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="../css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="../css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="../css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="../css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="../css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="../css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="../css/ashish.css" type="text/css">
    <link rel="stylesheet" href="../css/style.css" type="text/css">
 
</head>
<body>
<header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <ul class="header__top__widget">
                        <li><p class="link2"><strong><b>Welcome to admin Panel <span class="miwt"> <?php echo $user ?></span></b></strong></p>  </li>
                    </ul>
                    </div>
                    <div class="col-lg-6">
                        <div class="header__top__right">
                            <ul class="header__top__widget">
                             <li class="miwt"><i class="fa fa-user" ></i><a href="profile.php" class="miwt"> Edit Profile <a href="signout.php" class="link2">||Signout</a> </li> 
                              </div>                  
                            </div>
                    </div>      
                </div>
                </div>
            </div>      
            <div class="container">
            <div class="row">
                <div class="col-lg-2">
                    <div class="header__logo">
                        <a href="./index.html"><img src="../img/logo.png" alt=""></a>
                    </div>
                </div>
                <div class="col-lg-10">
                    <div class="header__nav">
                        <nav class="header__menu">
                            <ul>
                            <li><a href="./index.php">Login</a></li>
                                <li><a href="travelmaster.php">Travel manager</a></li>
                                <li><a href="routemaster.php">Route manager</a></li>
                                <li><a href="booking.php">Booking manager </a></li>
                                         </ul>
                        </nav>
                    </div>
                </div>
            </div>
    </header>
    <div class="container">
	        <div class="row">
            <div class="col-lg-12 ">
    		<img class="img-responsive, img-rounded" src="../img/counter-bg.jpg" alt="">
		</div>
	</div>
    <div class="container">
    <div class="col-lg-3">
        <div class="contact__text">
            <div class="section-title">
            </div>
        </div>
    </div>
</div>
<div class=" team-title">
    <h2 class="head">Route delete ||&nbsp; <small><a href="routemaster.php" class="adm">route manager</a></small>
    </h2>
    <br>

    <div class="table-responsive">
		  <table class="table">
			<thead>
				<tr>
				<th>Title</th>
				<th>Description</th>
				<th>Kilometers</th>				
				</tr>
			</thead>
			<?php
				include("conn.php");
				$qry="select * from route";
				$rc=mysql_query($qry);
				while($r=mysql_fetch_array($rc))
				{
					echo"<tr><td>$r[1] <td>$r[2] <td>$r[3]  <td> <a href='rdelfire.php?id=$r[0]' class='ashish'>[DEL]</a>  </tr>";
				}
			?>	
		  </table>
		</div>
