<?php
	
	include("conn.php");
	$a=$_POST['code'];
	$b=$_POST['name'];
	$c=$_POST['dis'];
	$d=$_POST['scap'];
	$e=$_POST['lcap'];
	$m=$_POST['ac'];
	$g=$_POST['wifi'];
	$h=$_POST['lcd'];
	$i=$_POST['music'];
	$k=$_POST['km'];
	$l=$_POST['p'];
	$image=$a.".jpg";
	$f=$_POST['c'];
	
	$dest="\vehicle_img".$image;
	copy($_FILES[userfile][tmp_name],$dest);
	
	$_FILES[userfile][width];
	$_FILES[userfile][height];
	
	
	$ans=mysql_query("insert into vehicle_master values('$a','$b','$c','$d','$e','$m','$g','$h','$i','$k','$l','$image','$f');");
	if($ans==1)
	{
			echo"<script>window.location='index.php'; </script>";
			
	}
	
?>
