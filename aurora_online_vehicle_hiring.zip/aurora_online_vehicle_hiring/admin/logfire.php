<?php

	$a = $_POST["txtlog"];
	$b = $_POST["txtpas"];	
	
	include("conn.php");
	$sel = "select * from cpanel where login='$a' and pass='$b' ";
	$res = mysql_query($sel);
	$count = mysql_num_rows($res);
	
	if($count==1)
	{
		session_start();
		$_SESSION['admin']=$a;	
		echo "<script> alert('Login Successfully'); </script>";
		echo "<script> window.location = 'travelmaster.php' </script>";
	}
	else
	{
		echo "<script> alert('Login credential are incorrect'); </script>";
		echo "<script> window.location = 'index.php' </script>";
	}
	
	
	
?>