<?php
	$route=$_GET['r'];
	session_start();
	$_SESSION['route']=$route;
	echo "<script> alert($route); </script>";
	echo "<script> window.location='index.php' </script>";
?>