<?php
	include('conn.php');
	$a=$_POST['username'];
	$c=$_POST['email'];
	$d=$_POST['ans'];
	
	$rc=mysql_query(" select * from register where username='$a'  and email='$c' and answer='$d' ");
	$row=mysql_fetch_array($rc);
	echo "<script> alert('Password : $row[5]'); </script>";
	echo "<script> window.location='signin.php'; </script>";

?>