<?php
	$vehicle=$_GET['code'];
	session_start();
	$_SESSION['vehicle']=$vehicle;
	echo "<script> window.location='book.php' </script>";
?>