<?php include('header.php') ?>
<div class="breadcrumb-option set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>About Aurora online vehicle hiring</h2>
                        <div class="breadcrumb__links">
                            <a href="./index.php"><i class="fa fa-home"></i>back to Home page</a>
                            <span></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="about spad">
        
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title about-title">
                    <span>About </span>
                    <h2>Aurora online vehicle hiring<br />
                        <p>We provide multiple packages in Porbandar as per your requirement. You can hire as per trip packages from Porbandar. Hire car on rent in Porbandar at Aurora Tour & Travels Car Rentals and travel to any part of the city at any time. Book your services with just a couple of clicks. We assure you the best services in Porbandar. If you have to book weekend getaways within your city, Aurora Tour & Travels provides the best packages for car rental.

Hire car on rent in Porbandar at Sonal Car Rentals and travel to any part of the city at any time. Book your services with just a couple of clicks. We assure you the best services in Porbandar. If you have to book weekend getaways within your city, Sonal provides the best packages for car rental in your city.

Booking with Sonal is very easy with just a few clicks. Sonal is best in the market for its reliable services, courteous drivers, and timely services. We offer you the best facilities and services to make your journey comfortable. You surely will have a good time by availing the services for your trip.

We provide the best Porbandar fare which is affordable for our customers. Avail our services at the most reliable rates in the city. By booking online taxi in Porbandar, you can visit your favourite local places.   </p>
                    </div>
                </div>
            </div>
    <div class="about__feature">
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="about__feature__item">
                            <img src="img/about/af-1.png" alt="">
                            <h5> Best Quality </h5>
                            <p>We provide best quality service for your trip.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="about__feature__item">
                           </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="about__feature__item">
                            <img src="img/about/af-2.png" alt="">
                            <h5>Trust</h5>
                            <p>We provide best vehicles and our trustable drivers for your trip.</p>
                        </div>
                    </div>
                 </div>
            </div>
            <div class="counter spad set-bg" data-setbg="img/counter-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="counter__item">
                        <h2 class="counter-num">110</h2>
                        <p>Vehicles In Stock</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="counter__item">
                        <h2 class="counter-num">65</h2>
                        <strong>+</strong>
                        <p>Vehicles Hired</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="counter__item">
                        <h2 class="counter-num">1130</h2>
                        <p>Clients Reviews</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="counter__item">
                        <h2 class="counter-num">4523</h2>
                        <p>Happy Clients</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

        </section>

<?php include('footer.php') ?>
