<?php include('header.php') ?>
<?php
  
    $code=$_GET['code'];
	$qry="select * from vehicle_master where code='$code'";
	$rc=mysql_query($qry);
	$row=mysql_fetch_array($rc);
	//$desc=$_GET['desc'];
?>

<div class="breadcrumb-option set-bg" data-setbg="img/call-bg.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <div class="breadcrumb__links">
                        <a href="index.php"><i class="fa fa-home"></i>Back to home page</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<section class="about spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title about-title">
                    <div class="car__item__text">
                         <div class="col-lg-12">
                         <h3 class="mycl"><?php echo $row[1]?></h3>
        </div> 
</div>  
    <?php echo "<img class='img-responsive img-hover' src='admin/vehicle_img/$row[11]'>"; ?>               
</div>
</div>
</div>
</div>
<div class="container">
<div class="section-title about-title">
<div class="car__item__text">
<br><h2>Description </h2>
<p><?php echo $row[2] ?></p>
<br>
<div class="container">
<div class="col-md-12">    

<br><h2> Vehicle configration </h2>
<div class="table-responsive">
<table class="table">
 <tr><td> <h5 class="db">Seat Capacity</td>
 <td><h5 class="db"><?php echo $row[3] ?></h5></td></tr>
 <tr><td><h5 class="db">Laugage Cap</td>
 <td><h5 class="db"> <?php echo $row[4] ?></h5></td></tr>
<tr><td><h5 class="db">Air-Condition</h5></td> 
<td><h5 class="db"><?php echo $row[5] ?></h5></td></tr>
<tr><td><h5 class="db">Wifi</h5></td>
<td> <?php echo $row[6] ?></h5></td></tr>
<tr><td><h5 class="db" >LCD </h5></td>
<td> <?php echo $row[7] ?></h5></td></tr>
<tr><td><h5 class="db">Music System </h5></td>
<td> <?php echo $row[8] ?></h5></td></tr>
<tr><td><h5 class="db">Price-per-Km </h5></td>
 <td><?php echo $row[9] ?></h5></td></tr></table>
 <?php echo "<a  href='vehiclesel.php?code=$code'><button type='submit' class='site-btn col-lg-3'>Book Vehicle <i class='fa fa-car'></button></i></a> "; ?>
        </div>                         
</div>
</div>
</div>
</div>
</section>
<?php include('footer.php') ?>
