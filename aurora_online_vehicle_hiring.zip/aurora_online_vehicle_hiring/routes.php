<?php include('header.php')?>
    <!-- Header Section End -->

    <!-- Breadcrumb End -->
    <div class="breadcrumb-option set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>Famous routes</h2>
                        <div class="breadcrumb__links">
                            <a href="./index.php"><i class="fa fa-home"></i> Home</a>
                            <span>routes</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Begin -->

    <!-- Contact Section Begin -->
    <section class="contact spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="contact__text">
                        <div class="section-title">
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
		  <table class="table">
			<thead>
				<tr>
				<th>Route Name</th>
				<th>Route Description</th>
				<th>Kms.</th>
				<th>&nbsp;</th>
				</tr>
			</thead>
            <?php
				
				$qry="select * from route";
				$rc=mysql_query($qry);
				while($r=mysql_fetch_array($rc))
				{
					echo"<tr><td><strong>$r[1]</strong> <td>$r[2] <td>$r[3] <td> <a href='routesel.php? r=$r[0]' class='ashish' >[Select]</a>  </tr>";
				}
			?>	

</table>
            </section>
    <!-- Contact Section End -->

    <!-- Contact Address End -->

  </body>
</html>
<?php include('footer.php')?>