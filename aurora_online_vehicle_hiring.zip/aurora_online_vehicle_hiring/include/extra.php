</div>
    <section class="contact spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="contact__text">
                        <div class="section-title">
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="contact__form">
                        <form action="#" method="post" >
                        <div class="row">
                                    <div class="form-group col-md-12 ">
                                        <label class="col-md-12 "> Select routes from below:-?</label>
                                        <div class="col-md-12 drop" >
                                            <select name="seq" class="form-control"  required>   
                                                <option> Porbandaer to jamnagar  </option>
                                                <option> Porbandaer to rajkot </option>
                                                <option> Porbandaer to morbi </option>
                                                <option> Porbandaer to ahmdabad </option>    
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-12">
                                        <label class="col-md-12 "> Select vehicles from below:-</label>
                                        <div class="col-md-12">
                                            <select name="seq" class="form-control"  required>
                                                <option> maruti  swift desire  </option>
                                                <option>maruti  swift desire </option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-12">
                             
                                <input type="submit" class="site-btn mybtn col-2" value="Get estimate..!">