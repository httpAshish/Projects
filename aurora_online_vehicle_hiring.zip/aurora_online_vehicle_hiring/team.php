<?php
    $a = $_POST["name"];
	$b = $_POST["email"];
	$c = $_POST["number"];
    $d = $_POST["seq"];
    include("conn.php");
    $qry="insert into about values('$a','$b','$c','$d')";    
    $res=mysql_query($qry);
    echo $res;
     if($res==1)
     {
         echo "<script> alert('Record inserted successfully')</script>";
         echo "<script> window.location.href='signin.php' </script>";
       }
        else{
            echo"<script> alert('error 404')</script>";
        }
?>
