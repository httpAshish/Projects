    <?php include('header.php')?>
<!-- Header Section End -->
<script language="javascript">
	function check()
	{
		if(document.frm.txtfname.value == "")
		{
			alert("Input First Name");
			document.frm.txtfname.focus();
			return false;
		}
		if(document.frm.txtlname.value == "")
		{
			alert("Input Last Name");
			document.frm.txtlname.focus();
			return false;
		}
		if(document.frm.txtaddr.value == "")
		{
			alert("Input Address");
			document.frm.txtaddr.focus();
			return false;
		}
		if(document.frm.txtcity.value == "")
		{
			alert("Input City Name");
			document.frm.txtcity.focus();
			return false;
		}
		if(document.frm.txtpin.value == "")
		{
			alert("Input Pincode");
			document.frm.txtpin.focus();
			return false;
		}
		if(document.frm.txtcontact.value == "")
		{
			alert("Input Contact Number");
			document.frm.txtcontact.focus();
			return false;
		}
		if(!checkEmail(document.frm.txtEmail.value))
		{
			alert("Enter Valid E-mail Address");
			document.frm.txtEmail.focus();
			document.frm.txtEmail.select();
			return false;
		}
		if(document.frm.txtuid.value == "")
		{
			alert("Input User Name");
			document.frm.txtuid.focus();
			return false;
		}
		if(document.frm.txtpass1.value == "")
		{
			alert("Input Password");
			document.frm.txtpass1.focus();
			return false;
		}
		if(document.frm.txtpass1.value.length<=5)
		{
			alert("Minimum input 6 characters");
			document.frm.txtpass1.focus();
			document.frm.txtpass1.select();
			return false;
		}
		if(document.frm.txtpass2.value != document.frm.txtpass1.value)
		{
			alert("Passwords are not match");
			document.frm.txtpass2.focus();
			document.frm.txtpass2.select();
			return false;
		}
		if(document.frm.lstsec.selectedIndex==0)
		{
			alert("Select proper security option" );
			document.frm.lstsec.focus();
			return false;
		}
		if(document.frm.txtans.value == "")
		{
			alert("Input Answer");
			document.frm.txtans.focus();
			return false;
		}
		if(document.frm.lstbank.selectedIndex==0)
		{
			alert("Select proper bank option" );
			document.frm.lstbank.focus();
			return false;
		}
		if(document.frm.txtbankacc.value == "")
		{
			alert("Input Bank Account Number");
			document.frm.txtbankacc.focus();
			return false;
		}
		
		function checkEmail(myForm)
		{
		if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(document.frm.txtEmail.value))
		{
			return (true)
		}
			return (false)
		}
	}
</script>

    <!-- Breadcrumb End -->
    <div class="breadcrumb-option set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>Register Your Account</h2>
                        <div class="breadcrumb__links">
                            <a href="./index.html"><i class="fa fa-home"></i> Home</a>C
                            <span>Registration </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Begin -->

    <!-- Contact Section Begin -->
    <section class="contact spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="contact__text">
                        <div class="section-title">
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="contact__form">
                        <form action="registerfire.php" method="post" name="myform">
                            <div class="row">
                                <div class="col-lg-6">
                                    <label>First name:- </label>
                                    <input type="username" name="fname" required>
                                    </div>
                                <div class="col-lg-6">
                                    <label>Last name:- </label>
                                    <input type="username" name="lname"  required>
                                </div>
                                <div class="col-lg-12">
                                    <label>Email- </label>
                                    <input type="email" name="email"  required>
                                </div>
                                <div class="col-lg-6">
                                    <label>Contact number </label>
                                    <input type="number" name="contact"  required>
                                </div>
                                <div class="col-lg-6">
                                    <label>Username:- </label>
                                    <input type="username"  name="username" required>
                                </div>
                                <div class="col-lg-6">
                                    <label>Password:- </label>
                                    <input type="password" name="pass" required>
                                </div>
                                <div class="col-lg-6">
                                    <label>Retype password:- </label>
                                    <input type="password" name="cpass" required>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-12">
                                        <label class="col-md-12"> security questions?</label>
                                        <div class="col-md-12">
                                            <select name="seq" class="form-control col-lg-12"  style="width: 750px;  font-size:50px; height: 58px; " required>
                                                <option> Select security Question from the list.. </option>
                                                <option> What is your favourite colour? </option>
                                                <option> What is your favourite fruite? </option>
                                                <option> what is your childhood name? </option>
                                                <option> which is your favourite sports? </option>    
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label>Answer </label>
                                    <input name="ans" type="text"  required>
                                </div>
                                <div class="text-center col-lg-12">
                                <button type="submit" class="site-btn col-lg-12">Register </button>
                                </div>
                                    <br>
                                <div class="col-lg-12">   
                                </div>
                                <div class="col-lg-7">   
                                </div> 
                                <div class="col-lg-4">   
                                 <a href="Signin.php" class="ashish">Already have account </a>
                                </div>
                            </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
       
        </div>
        </div>
    </section>
    <!-- Contact Section End -->

    <!-- Contact Address End -->

   </body>

</html>
<?php include('footer.php')?>   