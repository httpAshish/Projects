<?php
    $a = $_POST["user"];
	$b = $_POST["email"];
	$c = $_POST["comm"];
  
    include("conn.php");
    $qry="insert into feedback values('$a','$b','$c')";    
    $res=mysql_query($qry);
    //echo "'$a','$b','$c'";
     if($res==1)
     {
         echo "<script> alert('thankyou for your feedback')</script>";
         echo "<script> window.location.href='index.php' </script>";
       }
        else{
            echo"<script> alert('error 404')</script>";
        }
?>