<?php include('header.php') ?>
<div class="breadcrumb-option set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>About our developers</h2>
                        <div class="breadcrumb__links">
                            <a href="./index.php"><i class="fa fa-home"></i>back to Home page</a>
                            <span></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<section class="about spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title about-title">
                    <span>our team </span>
                    <h2>Welcome to our website <br />
                        <p>First I will explain my self i am Ashish vaja and i am working in this project Aurora
                            online vehicle hiring in this project i have  3 more members in this. their names are
                            Umang nandha,Ronit motivaras and jay joshi.we are students of diploma polytechnic government
                            collage. we are studying computer engineering in 6th sem. our team have a best members to 
                            manage the website we have ronit motivaras he is a best program tester,we have jay joshi
                            he had a good knowledge of graphic designing so he help me to find logo and photographs that
                            i used in this website,our team have umang nandha he had a exellent knowledge of php language
                            he do our database connection to our website,and i've design the website.
                        </p>
                    </div>
                </div>
            </div>
</section>
<section class="team spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title team-title">
                        <span>Our Team</span>
                        <h2>Meet Our Members</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-sm-6">
                    <div class="team__item">
                        <div class="team__item__pic">
                            <img src="img/about/aashu.jpg" alt="">
                        </div>
                        <div class="team__item__text">
                            <h5>Ashish Vaja</h5>
                            <span>Front-end developer</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="team__item">
                        <div class="team__item__pic">
                            <img src="img/about/ronit.jpg" alt="">
                        </div>
                        <div class="team__item__text">
                            <h5>Ronit motivaras</h5>
                            <span>Code tester</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="team__item">
                        <div class="team__item__pic">
                            <img src="img/about/umang.jpg" alt="">
                        </div>
                        <div class="team__item__text">
                            <h5>Umang Nandha</h5>
                            <span>Back-end developer</span>
                        </div>
                    </div>
                </div>
           
                <div class="col-lg-3 col-sm-6">
                    <div class="team__item">
                        <div class="team__item__pic">
                            <img src="img/about/jay.jpg" alt="">
                        </div>
                        <div class="team__item__text">
                            <h5>Jay joshi</h5>
                            <span>Graphic Designer</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="call spad set-bg" data-setbg="img/about/call-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-6">
                    <div class="call__text">
                        <div class="section-title">
                            <h2>Contact Us</h2>
                        <p> contact our team or any work query. </p>
                      </div>
                    </div>
                </div>
                <div class="col-lg-6 offset-lg-1 col-md-6">
                    <form action="team.php" method="post" class="call__form">
                        <div class="row">
                            <div class="col-lg-6">
                                <input type="name" name="name" placeholder="Name" required>
                            </div>
                            <div class="col-lg-6">
                                <input type="email" name="email" placeholder="email" required>
                            </div>
                            <div class="col-lg-6">
                                <input type="number" name="number" placeholder="number" required>
                            </div>
                            <div class="col-lg-6">
                            <select name="seq" required>
                                    <option >Whoom are you looking for?</option>
                                     <option>Ashish vaja</option>
                                    <option >Umang Nandha</option>
                                    <option >Ronit Motivaras</option>
                                    <option>Jay joshi</option>   
                                  </select>
                            </div>
                         </div>
                        <button type="submit" class="site-btn">Submit..!</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <section class="testimonial spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title testimonial-title">
                        <span>Thank you</span>
                        <h2>Have a good day...!</h2>
                        <p>Thank you for visiting.</p>
                    </div>
                </div>
            </div>
</section>
</body>

<?php include('footer.php') ?>