<section id="home" class="video-hero" style="height: 800px; background-image: url(images/nikon.jpg);  background-size:cover; background-position: center center;background-attachment:fixed;" data-section="home">
    <div class="overlay"></div>
        <a class="player" data-property="{videoURL:'https://www.youtube.com/watch?v=Yz5-mrDBbxU',containment:'#home', showControls:false, autoPlay:true, loop:true, mute:true, startAt:0, opacity:1, quality:'default'}"></a> 
        <div class="display-t text-center">
            <div class="display-tc">
                <div class="container">
                    <div class="col-md-10 col-md-offset-1">
                        <div class="animate-box">
                        <!--	<h1 class="holder"><span>Fashion Photoshoot</span></h1> -->
                            <h2>"Photography is the story I fail to put into words"</h2>
                            <p>Bhole Creation</p> 
                          <a href="gallery.php" class="btn-primary btn btn-custom">View Portfolio</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div id="colorlib-services">
        <div class="container">
            <div class="row">
                <div class="col-md-4 text-center animate-box">
                    <div class="services">
                        <span class="icon">
                            <i class="icon-camera4"></i>
                        </span>
                        <div class="desc">
                                <h3>Photography</h3>
                            <p>We can do Wedding photography<br>Fashion-photography,Pre-wedding shoot<br>Baby Shoot</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 text-center animate-box">
                    <div class="services">
                        <span class="icon">
                            <i class="icon-image"></i>
                        </span>
                        <div class="desc">
                            <h3>Image Processing</h3>
                            <p>We can do Normal-Retouching,<br>Album-designing, make Visting-card<br>Graphic-designing</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 text-center animate-box">
                    <div class="services">
                        <span class="icon">
                            <i class="icon-video3"></i>
                        </span>
                        <div class="desc">
                            <h3>Videography</h3>
                            <p>We can do Pre-wedding,<br>Cinematic-shoot and <br>Wedding Videography  </p>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
					<div class="col-md-12 text-center animate-box">
						<div class="staff-entry">
							<a href="#" class="staff-img" style="background-image: url(images/mad.jpg);"></a>
							<div class="desc">
								<h3>Vishal Vaja</h3>
								<span>Photographer|Editor</span>
								<p>My name is vishal and i love to click photographs and design them,<br>before Bhole creation i used to click photographs for fun but now its mine bussiness. </p>
								<p>
									<ul class="colorlib-social-icons">
										<li><a href="https://www.facebook.com/vd_vaja/"><i class="icon-facebook2"></i></a></li>
										<li><a href="https://www.instagram.com/vishu_vaja/"><i class="icon-instagram"></i></a></li>
										<li><a href="#"><i class="icon-youtube"></i></a></li>
									</ul>
								</p>
							</div>
						</div>
					</div>
			</div>
   <div class="colorlib-gallery">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-8 col-md-offset-2 text-center colorlib-heading animate-box">
                        <h2>Contemporary  Work <i class="icon-image"></i></h2>
                   
                </div>
            </div>
            <div class="row">
                <div class="col-md-3 no-gutters">
                    <a href="images/gallery-1.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/gallery-1.jpg" alt="">
                        <div class="desc text-center">
                        <p class="category"><span>Fashion</span></p>                         </div>
                    </a>
                </div>
                <div class="col-md-3 no-gutters">
                    <a href="images/IMG_8399_resize.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/IMG_8399_resize.jpg" alt="">
                        <div class="desc text-center">
                            <p class="category"><span>Fade</span></p>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 no-gutters">
                    <a href="images/gallery-5.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/gallery-5.jpg" alt="">
                        <div class="desc text-center">
                            <p class="category"><span>Vogue</span></p>
                        </div>
                    </a>
                </div>
                    <div class="col-md-3 no-gutters">
                    <a href="images/gallery-8.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/gallery-8.jpg" alt="">
                        <div class="desc text-center">
                            <p class="category"><span>Tradion</span></p>
                        </div>
                    </a>
                </div>
                <a href="images/design.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/design.jpg" alt="">
                        <div class="desc text-center">
                        <p class="category"><span>Wear</span></p>                         </div>
                    </a>          
            </div>
        </div>
    </div>
