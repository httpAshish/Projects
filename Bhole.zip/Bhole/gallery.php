<?php include('header.php') ?>
<section id="home" class="video-hero" style="height: 800px; background-image: url(images/12.jpg);  background-size:cover; background-position: center center;background-attachment:fixed;" data-section="home">
		<div class="overlay"></div>
			<div class="display-t text-center">
				<div class="display-tc">
					<div class="container">
						<div class="col-md-10 col-md-offset-1">
							<div class="animate-box">
								<h2>Gallery</h2>
								<p class="breadcrumbs"><span><a href="index.php">Home|</a></span> <span>|Gallery</span></p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
        <div class="colorlib-gallery">
			<div class="container">
				<div class="row row-pb-md">
					<div class="col-md-3 no-gutters">
					<a href="images/gal-2.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/gal-2.jpg" alt="">
							<div class="desc text-center">
								<p class="category"><span>Traditional</span></p>
							</div>
						</a>
</div>
					<div class="col-md-3 no-gutters">
					<a href="images/gallery-5.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/gallery-5.jpg" alt="">
					<div class="desc text-center">
					<p class="category"><span>Traditional</span></p>
							</div>
						</a>
						</div>
						<div class="col-md-3 no-gutters">
						<a href="images/gal-3.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/gal-3.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Traditional</span></p>
							</div>
						</a>
                    </div>
					<div class="col-md-3 no-gutters">
					<a href="images/mn.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/mn.jpg" alt="">
					<div class="desc text-center">
					<p class="category"><span>Traditional</span></p>
							</div>
						</a>
						</div>
					<div class="col-md-4 no-gutters">
						<a href="images/kl.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/kl.jpg" alt="">
							<div class="desc text-center">
							<h2> Couple Be Like </h2>
							<p class="category"><span>Milap</span> <span>Anisha</span></p>
						</div>
						</a>
                        </div>					
						<div class="col-md-4 no-gutters">
						<a href="images/0.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/0.jpg" alt="">
							<div class="desc text-center">
							<h2> Couple Be Like </h2>
							<p class="category"><span>Milap</span> <span>Anisha</span></p>
							</div>
						</a>
                        </div>					
						<div class="col-md-4 no-gutters">
						<a href="images/gal-7.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/gal-7.jpg" alt="">
							<div class="desc text-center">
							<h2> Couple Be Like </h2>
							<p class="category"><span>Milap</span> <span>Anisha</span></p>
							</div>
						</a>
                        </div>
						<div class="col-md-3 no-gutters">
						<a href="images/gal-4.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/gal-4.jpg" alt="">
							<div class="desc text-center">
								<p class="category"><span>Fashion Photography</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-3 no-gutters">
						<a href="images/gallery-8.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/gallery-8.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Fashion Photography</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-3 no-gutters">
						<a href="images/bh.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/bh.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Fashion Photography</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-3 no-gutters">
						<a href="images/bd.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/bd.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Fashion Photography</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-4 no-gutters">
						<a href="images/gall-8.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/gall-8.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Mehndi Vibes</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-4 no-gutters">
						<a href="images/gall-10.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/gall-10.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Fashion Photography</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-4 no-gutters">
						<a href="images/gall-9.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/gall-9.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Mehndi Vibes</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-4 no-gutters">
						<a href="images/gall-01.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/gall-01.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Light House</span> 
							</div>
						</a>
                        </div>
						
						<div class="col-md-4 no-gutters">
						<a href="images/gall-03.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/gall-03.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Light House</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-4 no-gutters">
						<a href="images/gall-02.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/gall-02.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Light House</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-3 no-gutters">
						<a href="images/IMG_8391_resize.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/IMG_8391_resize.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Ganesh chaturti Special</span> 
							</div>
						</a>
                        </div>	
						<div class="col-md-3 no-gutters">
						<a href="images/IMG_8396 copy_resize.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/IMG_8396 copy_resize.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Ganesh chaturti Special</span> 
							</div>
						</a>
                        </div>	
						<div class="col-md-3 no-gutters">
						<a href="images/IMG_8400_resize.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/IMG_8400_resize.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Ganesh chaturti Special</span> 
							</div>
						</a>
                        </div>				
					   <div class="col-md-3 no-gutters">
						<a href="images/IMG_8399_resize.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/IMG_8399_resize.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Ganesh chaturti Special</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-3 no-gutters">
						<a href="images/rr.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/rr.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Fade</span> 
							</div>
						</a>
						<a href="images/pp.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/pp.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Paut</span> 
							</div>
						</a>
						<a href="images/rasshi.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/rasshi.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Fade</span> 
							</div>
						</a>
                        </div>
						
						<div class="col-md-3 no-gutters">
						<a href="images/oo.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/oo.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Fade</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-3 no-gutters">
						<a href="images/kp.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/kp.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Fade</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-3 no-gutters">
						<a href="images/sehu.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/sehu.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Paut</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-3 no-gutters">
						<a href="images/rashu.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/rashu.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Traditional</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-6 no-gutters">
						<a href="images/vd.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/vd.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Collage</span> 
							</div>
						</a>
                        </div>
					
					</div>						
					</div>
				</div>
			</div>
		</div>
<?php include('footer.php') ?>