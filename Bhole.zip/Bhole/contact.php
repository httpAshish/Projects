<?php include('header.php')?>
<section id="home" class="video-hero" style="height: 800px; background-image: url(images/12.jpg);  background-size:cover; background-position: center center;background-attachment:fixed;" data-section="home">
		<div class="overlay"></div>
			<div class="display-t text-center">
				<div class="display-tc">
					<div class="container">
						<div class="col-md-10 col-md-offset-1">
							<div class="animate-box">
								<h2>Contact Us</h2>
								<p class="breadcrumbs"><span><a href="index.php">Home|</a></span> <span>|Contact</span></p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<div id="colorlib-contact">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-md-push-8 animate-box">
						<h2>Contact Information</h2>
						<div class="row">
							<div class="col-md-12">
								<div class="contact-info-wrap-flex">
									<div class="con-info">
										<p><span><i class="icon-location-2"></i></span> Porbandar(360-575), <br> Gujrat India </p>
									</div>
									<div class="con-info">
										<p><span><i class="icon-phone3"></i></span> <a href="tel://1234567920">+91 8780564301</a></p>
									</div>
									<div class="con-info">
										<p><span><i class="icon-paperplane"></i></span> <a href="mailto:info@yoursite.com">bholephotography7.com</a></p>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-8 col-md-pull-4 animate-box">
						<h2>Get In Touch</h2>
						<form action="contactfire.php" method="post">
							<div class="row form-group">
								<div class="col-md-12">
									 <label for="fname">First Name</label> 						
						            	<input type="text" id="fname" name="name" class="form-control" placeholder="your name">
								</div>
							</div>

							<div class="row form-group">
								<div class="col-md-12">
									 <label for="email">Email</label> 
									<input type="text" id="email" name="email" class="form-control" placeholder="Your email address">
								</div>
							</div>

							<div class="row form-group">
								<div class="col-md-12">
									 <label for="subject">mobile number</label>
									<input type="mobile number" id="subject" name="mobile" class="form-control" placeholder="your mobile number">
								</div>
							</div>

							<div class="row form-group">
								<div class="col-md-12">
									 <label for="message">Message</label> 
									<textarea  id="message" cols="30" name="msg" rows="10" class="form-control" placeholder="Say something about us"></textarea>
								</div>
							</div>
							<div class="form-group">
								<input type="submit" value="Send Message" class="btn btn-primary">
							</div>
						</form>		
				<div class="container">
				<div class="row row-pb-lg">			
				<div class="col-md-12 animate-box">					 
				<div id="map">
                	<!-- How to change your own map point
                           1. Go to Google Maps
                           2. Click on your location point
                           3. Click "Share" and choose "Embed map" tab
                           4. Copy only URL and paste it within the src="" field below
                    -->
					<h1>Find our live location</h2>
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3708.648720596705!2d69.60378708444006!3d21.638607874278193!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3956345a65061a1b%3A0x69c84699dcda6ece!2sUganda%20Rd%2C%20Panch%20Hatdi%2C%20Porbandar%2C%20Gujarat%20360575!5e0!3m2!1sen!2sin!4v1654788505659!5m2!1sen!2sin" width="100%" height="400px" frameborder="0" style="border:0" allowfullscreen   alt="Please check your internet connection"></iframe>
                </div>
				</div>
				</div>
	     		</div>
	            </div>
	 			</div>
				</div>
				
				</div>
		
<?php include('footer.php')?>