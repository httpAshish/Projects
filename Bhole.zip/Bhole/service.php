<?php include('header.php')?>
		<section id="home" class="video-hero" style="height: 800px; background-image: url(images/12.jpg);  background-size:cover; background-position: center center;background-attachment:fixed;" data-section="home">
		<div class="overlay"></div>
			<div class="display-t text-center">
				<div class="display-tc">
					<div class="container">
						<div class="col-md-10 col-md-offset-1">
							<div class="animate-box">
								<h2>Services</h2>
								<p class="breadcrumbs"><span><a href="index.php">Home|</a></span> <span>|Services</span></p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>


		<div id="colorlib-services">
        <div class="container">
            <div class="row">
                <div class="col-md-4 text-center animate-box">
                    <div class="services">
                        <span class="icon">
                            <i class="icon-camera4"></i>
                        </span>
                        <div class="desc">
                                <h3>Photography</h3>
                            <p>We do Wedding photography<br>Fashion-photography,Pre-wedding shoot<br>Baby Shoot</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 text-center animate-box">
                    <div class="services">
                        <span class="icon">
                            <i class="icon-image"></i>
                        </span>
                        <div class="desc">
                            <h3>Image Processing</h3>
                            <p>We do Normal-Retouching,<br>Album-designing, make Visting-card<br>Graphic-designing</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 text-center animate-box">
                    <div class="services">
                        <span class="icon">
                            <i class="icon-video3"></i>
                        </span>
                        <div class="desc">
                            <h3>Videography</h3>
                            <p>We do Pre-wedding,<br>Cinematic-shoot and <br>Wedding Videography  </p>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
        <?php include('footer.php')?>