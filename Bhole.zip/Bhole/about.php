<?php include('header.php') ?>

<section id="home" class="video-hero" style="height: 800px; background-image: url(images/bb.jpg);  background-size:cover; background-position: center center;background-attachment:fixed;" data-section="home">
		<div class="overlay"></div>
			<div class="display-t text-center">
				<div class="display-tc">
					<div class="container">
						<div class="col-md-10 col-md-offset-1">
							<div class="animate-box">
								<h2>About Us</h2>
								<p class="breadcrumbs"><span><a href="index.php">Home|</a></span> <span>|About</span></p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<div id="colorlib-about">
			<div class="container">
				<div class="row row-pb-lg">
					<div class="col-md-6 animate-box">
						<div class="video colorlib-video" style="background-image: url(images/01.jpg);">
				<div class="overlay"></div>
						</div>
					</div>
					<div class="col-md-6 animate-box">
						<h2> Bhole Creation</h2>
						<p>"We capture your memories forever"</p>
						<p>At Bhole creation we aim to capture your special moments to teasure forever,we'll capture your smile your tears and your joyfull moments by our cameras and will it presented in high quality photographs and videos.</p>
						<p>Any work query you can easily contact us. 
					</div>
				</div>
				<div class="col-md-12 text-center animate-box">
						<div class="staff-entry">
							<a href="#" class="staff-img" style="background-image: url(images/mad.jpg);"></a>
							<div class="desc">
								<h3>Vishal Vaja</h3>
								<span>Photographer|Editor</span>
								<p>My name is vishal and i love to click photographs and design it,before Bhole creation i use to click photographs for fun but now it's my bussiness. </p>
								<p>
									<ul class="colorlib-social-icons">
										<li><a href="#"><i class="icon-facebook2"></i></a></li>
										<li><a href="#"><i class="icon-instagram"></i></a></li>
										<li><a href="#"><i class="icon-youtube"></i></a></li>
									</ul>
								</p>
							</div>
						</div>
					</div>
                </div>
			</div>
<?php include('footer.php') ?>