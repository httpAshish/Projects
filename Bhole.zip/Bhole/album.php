<?php include('header.php') ?>
<section id="home" class="video-hero" style="height: 800px; background-image: url(images/12.jpg);  background-size:cover; background-position: center center;background-attachment:fixed;" data-section="home">
		<div class="overlay"></div>
			<div class="display-t text-center">
				<div class="display-tc">
					<div class="container">
						<div class="col-md-10 col-md-offset-1">
							<div class="animate-box">
								<h2>Gallery</h2>
								<p class="breadcrumbs"><span><a href="index.php">Home|</a></span> <span>|Gallery</span></p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
        <div class="colorlib-gallery">
			<div class="container">
				<div class="row row-pb-md">
					<div class="col-md-6 no-gutters">
						<a href="images/design-2.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/design-2.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Album design</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-6 no-gutters">
						<a href="images/design.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/design.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Album design</span> 
								</div>
						</a>
                        </div>
						<div class="col-md-6 no-gutters">
						<a href="images/al1.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/al1.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Album design</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-6 no-gutters">
						<a href="images/al2.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/al2.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Album design</span> 
							</div>
						</a>
                        </div>
					
						<div class="col-md-6 no-gutters">
						<a href="images/al3.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/al3.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Album design</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-6 no-gutters">
						<a href="images/al4.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/al4.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Album design</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-6 no-gutters">
						<a href="images/al5.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/al5.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Album design</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-6 no-gutters">
						<a href="images/al8.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/al8.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Album design</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-6 no-gutters">
						<a href="images/al7.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/al7.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Album design</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-6 no-gutters">
						<a href="images/al6.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/a6.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Album design</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-6 no-gutters">
						<a href="images/al9.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/al9.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Album design</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-6 no-gutters">
						<a href="images/al1.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/al1.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Album design</span> 
							</div>
						</a>
                        </div>
						<div class="col-md-6 no-gutters">
						<a href="images/al10.jpg" class="gallery-img image-popup-link animate-box"><img class="img-responsive" src="images/al10.jpg" alt="">
							<div class="desc text-center">
							<p class="category"><span>Album design</span> 
							</div>
						</a>
                        </div>
					
						</div>
                        	
				</div>
			</div>
		</div>
<?php include('footer.php') ?>