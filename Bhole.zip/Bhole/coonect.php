<?php

$server = "localhost";
$username = "root";
$password = "";
$dbname = "bhole";
$conn = mysql_connect($server,$username,$password);
$db = mysql_select_db($dbname);

?>