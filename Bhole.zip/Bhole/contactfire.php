<?php
    $a = $_POST["name"];
	$b = $_POST["email"];
	$c = $_POST["mobile"];
    $d = $_POST["msg"];
  
    include("conn.php");
    $qry="insert into contact values('$a','$b','$c','$d')";    
    $res=mysql_query($qry);
    //echo "'$a','$b','$c'";
     if($res==1)
     {
         echo "<script> alert('thankyou for your feedback')</script>";
         echo "<script> window.location.href='index.php' </script>";
       }
        else{
            echo"<script> alert('error 404')</script>";
        }
?>