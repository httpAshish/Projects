<?php include('header.php')?>
<?php include('mid.php')?>
<?php include('footer.php')?>