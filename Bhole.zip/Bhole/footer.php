    
    <div id="colorlib-instagram">
        <div class="row">
            <div class="col-md-12 col-md-offset-0 colorlib-heading text-center animate-box">
                <h2><i class="icon-instagram"></i> Instagram</h2>
            </div>
        </div>
        <div class="row">
            <div class="instagram-entry animate-box">
                <a href="https://www.instagram.com/bhole__photographer/" target="blank" class="instagram text-center" style="background-image: url(images/insta-1.jpg);">
                </a>
                <a href="https://www.instagram.com/bhole__photographer/"target="blank" class="instagram text-center" style="background-image: url(images/insta-2.jpg);">
                </a>
                <a href="https://www.instagram.com/bhole__photographer/"target="blank" class="instagram text-center" style="background-image: url(images/insta-3.jpg);">
                </a>
                <a href="https://www.instagram.com/bhole__photographer/"target="blank" class="instagram text-center" style="background-image: url(images/insta-4.jpg);">
                </a>
                <a href="https://www.instagram.com/bhole__photographer/" target="blank" class="instagram text-center" style="background-image: url(images/insta-5.jpg);">
                </a>
                <a href="https://www.instagram.com/bhole__photographer/"target="blank" class="instagram text-center" style="background-image: url(images/0.jpg);">
                </a>
                <a href="https://www.instagram.com/bhole__photographer/"target="blank" class="instagram text-center" style="background-image: url(images/insta-8.jpg);">
                </a>
                <a href="https://www.instagram.com/bhole__photographer/"target="blank" class="instagram text-center" style="background-image: url(images/insta-14.jpg);">
                </a>
               
            </div>
        </div>
    </div>

<footer id="colorlib-footer">
    <div class="container">
        <div class="row row-pb-md">
            <div class="col-md-4 colorlib-widget">
                
                <h4>About Bhole Photography</h4>
                <p>We can do all type photography<br> Videography and Designing works.<br>you can contact through social-media <br>or by using website. </p>
                <p>
                    <ul class="colorlib-social-icons">
                        <li><a href="#"><i class="icon-twitter2"></i></a></li>
                        <li><a href="#"><i class="icon-facebook2"></i></a></li>
                        <li><a href="#"><i class="icon-instagram"></i></a></li>
                        <li><a href="#"><i class="icon-youtube2"></i></a></li>
                    </ul>
                </p>
            </div>
            <div class="col-md-4 colorlib-widget">
                <h4>Information</h4>
                <p>
                    <ul class="colorlib-footer-links">
                        <li><a href="index.php"><i class="icon-check"></i> Home</a></li>
                        <li><a href="gallery.php"><i class="icon-check"></i> Gallery</a></li>
                        <li><a href="about.php"><i class="icon-check"></i> About</a></li>
                        <li><a href="service.php"><i class="icon-check"></i> Services</a></li>
                        <li><a href="contact.php"><i class="icon-check"></i> Contact</a></li>
                        

                    </ul>
                </p>
            </div>
            <div class="col-md-4 colorlib-widget">
                <h4>Contact Info</h4>
                <ul class="colorlib-footer-links">
                    <li>Porbandar(360-575) <br> Gujrat,India</li>
                    <li><a href="tel://8780564301"><i class="icon-phone"></i>+91 91577 69061</a></li>
                    <li><a href="mailto:info@yoursite.com"><i class="icon-envelope"></i> bholephotography7.com</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="copy">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <p>
                        <small class="block">Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved ||Bhole photography  
                    </p>
                </div>
            </div>
        </div>
    </div>
</footer>
</div>

<div class="gototop js-top">
<a href="#" class="js-gotop"><i class="icon-arrow-up2"></i></a>
</div>

<!-- jQuery -->
<script src="js/jquery.min.js"></script>
<!-- jQuery Easing -->
<script src="js/jquery.easing.1.3.js"></script>
<!-- Bootstrap -->
<script src="js/bootstrap.min.js"></script>
<!-- Waypoints -->
<script src="js/jquery.waypoints.min.js"></script>
<!-- Stellar Parallax -->
<script src="js/jquery.stellar.min.js"></script>
<!-- YTPlayer -->
<script src="js/jquery.mb.YTPlayer.min.js"></script>
<!-- Owl carousel -->
<script src="js/owl.carousel.min.js"></script>
<!-- Magnific Popup -->
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/magnific-popup-options.js"></script>
<!-- Main -->
<script src="js/main.js"></script>

</body>
</html>

