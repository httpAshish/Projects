<?php
    $server = "sql203.epizy.com";
    $username = "epiz_32346796";
    $password = "hVYO2c8N8E";
    $dbname = "epiz_32346796_profile";
    $conn = mysql_connect($server,$username,$password);
    $db = mysql_select_db($dbname);

    $a = $_POST["name"];
	$b = $_POST["email"];
	$c = $_POST["number"];
	$c = $_POST["message"];
  
    $qry="insert into contact values('$a','$b','$c','$d')";    
    $res=mysql_query($qry);
    //echo "'$a','$b','$c'";
     if($res==1)
     {
         echo "<script> alert('thankyou for your feedback')</script>";
         echo "<script> window.location.href='index.html' </script>";
       }
        else{
            echo"<script> alert('error 404')</script>";
        }



?>